package model;

public class Conta extends Pessoa{

 
    
    
}
